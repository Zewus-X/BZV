Compass.add_project_configuration('../../../classic/theme-graphite/sass/config.rb')
